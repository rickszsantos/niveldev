/* ============================================================
   NívelDev — layout das telas logadas (home, exercícios, categoria)
   Monta o MENU LATERAL e o TOPO em um só lugar, então qualquer
   mudança no menu é feita aqui e vale para todas as telas.

   Como usar numa tela nova:
     <body class="app-page" data-pagina="nome-da-tela">
       <div class="app-shell">
         <div data-layout="menu"></div>
         <div class="app-main">
           <div data-layout="topo"></div>
           <main class="app-content" id="app-content"> ... </main>
         </div>
       </div>
       <script src="js/auth.js"></script>
       <script src="js/ui.js"></script>
       <script src="js/layout.js"></script>

   Também cuida de:
   - proteção da página (sem login → volta para login.html)
   - avatar e nome do usuário (confirma o token no servidor)
   - menu do usuário, notificações, tema claro/escuro, recolher menu
   - atalho Ctrl + K (ou "/") para focar a busca do topo

   Depende de js/auth.js, js/ui.js e js/preferencias.js.
   Outros scripts podem usar:  NivelDevLayout.usuario((user) => { ... })
   ============================================================ */

(function () {
  /* ---------- PROTEÇÃO DA PÁGINA ---------- */
  if (!window.NivelDevAuth || !NivelDevAuth.getToken()) {
    window.location.replace('login.html');
    return;
  }

  const pagina = document.body.dataset.pagina || '';
  const naHome = pagina === 'home';
  const $ = (id) => document.getElementById(id);

  /* ---------- MENU (edite aqui para mudar o menu de todas as telas) ---------- */
  const ICONE = {
    inicio:     '<path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-4v-6H9v6H5a1 1 0 01-1-1v-9z"/>',
    cursos:     '<path d="M2 9l10-5 10 5-10 5L2 9z"/><path d="M6 11.5V16c0 1.4 2.7 3 6 3s6-1.6 6-3v-4.5"/><path d="M22 9v6"/>',
    exercicios: '<path d="M8 8l-4 4 4 4"/><path d="M16 8l4 4-4 4"/><path d="M13.5 5l-3 14"/>',
    progresso:  '<rect x="3" y="13" width="4" height="7" rx="1.5"/><rect x="10" y="8" width="4" height="12" rx="1.5"/><rect x="17" y="3" width="4" height="17" rx="1.5"/>',
    perfil:     '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
  };

  // na home os itens trocam de "view" pela # da URL; nas outras telas levam para a home
  const base = naHome ? '' : 'home.html';
  const ITENS = [
    { id: 'inicio',     texto: 'Início',        href: base + '#inicio',    view: 'inicio' },
    { id: 'cursos',     texto: 'Cursos',        href: base + '#cursos',    view: 'cursos' },
    { id: 'exercicios', texto: 'Exercícios',    href: 'exercicios.html',   view: null },
    { id: 'progresso',  texto: 'Meu Progresso', href: base + '#progresso', view: 'progresso' },
    '---',
    { id: 'perfil',     texto: 'Meu Perfil',    href: base + '#perfil',    view: 'perfil' },
  ];

  // categoria.html pertence ao menu "Exercícios"
  const ativoNestaTela = pagina === 'categoria' ? 'exercicios' : pagina;

  const svg = (caminhos) => `<svg viewBox="0 0 24 24" aria-hidden="true">${caminhos}</svg>`;

  const htmlMenu = `
    <aside class="app-sidebar" id="app-sidebar" aria-label="Menu principal">
      <button type="button" class="app-collapse" id="app-collapse" aria-controls="app-sidebar">
        ${svg('<path d="M14.5 6l-6 6 6 6"/>')}
      </button>

      <a href="${naHome ? '#inicio' : 'home.html'}" class="app-logo" aria-label="NívelDev — início">
        <img class="app-logo-full logo-claro"  src="img/logo-niveldev.png"        alt="NívelDev">
        <img class="app-logo-full logo-escuro" src="img/logo-niveldev-branco.png" alt="NívelDev">
        <img class="app-logo-mini" src="img/logo-niveldev-icone.png" alt="" aria-hidden="true">
      </a>

      <nav class="app-nav">
        ${ITENS.map((i) => {
          if (i === '---') return '<hr class="app-nav-sep">';
          const ativo = i.id === ativoNestaTela;
          return `
        <a href="${i.href}" class="app-nav-item${ativo ? ' is-active' : ''}" data-tip="${i.texto}"
           ${i.view ? `data-view="${i.view}"` : ''} ${ativo ? 'aria-current="page"' : ''}>
          ${svg(ICONE[i.id])}
          <span class="app-nav-label">${i.texto}</span>
        </a>`;
        }).join('')}
      </nav>
    </aside>`;

  /* ---------- TOPO ---------- */
  // As notificações abaixo são EXEMPLOS. Quando existir uma API, troque por dados reais.
  const htmlTopo = `
    <header class="app-topbar">
      <label class="app-busca">
        ${svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>')}
        <input type="search" id="app-busca-global" placeholder="Buscar cursos, exercícios…" autocomplete="off" aria-label="Busca geral">
        <kbd aria-hidden="true">Ctrl K</kbd>
      </label>

      <div class="app-acoes">
        <button type="button" class="app-icon-btn" id="btn-tema" aria-label="Alternar tema claro e escuro">
          <span class="icone-lua">${svg('<path d="M20 14.5A8.5 8.5 0 019.5 4 8.5 8.5 0 1020 14.5z"/>')}</span>
          <span class="icone-sol">${svg('<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>')}</span>
        </button>

        <div class="app-pop">
          <button type="button" class="app-icon-btn" id="btn-notif" aria-haspopup="true" aria-expanded="false" aria-label="Notificações">
            ${svg('<path d="M6 16V11a6 6 0 1112 0v5l1.5 2h-15L6 16z"/><path d="M10 21h4"/>')}
            <span class="app-ponto" id="notif-ponto" aria-hidden="true"></span>
          </button>
          <div class="app-menu-pop app-notif" id="menu-notif" hidden>
            <p class="app-pop-titulo">Notificações</p>
            <ul class="app-notif-lista">
              <li class="is-nova"><span class="app-notif-icone">${svg('<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7L12 3z"/>')}</span>
                <div><strong>Você subiu para o nível 7!</strong><span>há 2 horas</span></div></li>
              <li class="is-nova"><span class="app-notif-icone">${svg('<path d="M8 8l-4 4 4 4"/><path d="M16 8l4 4-4 4"/><path d="M13.5 5l-3 14"/>')}</span>
                <div><strong>Novo desafio semanal disponível</strong><span>ontem</span></div></li>
            </ul>
          </div>
        </div>

        <div class="app-pop">
          <button type="button" class="app-user-btn" id="app-user-btn" aria-haspopup="true" aria-expanded="false" aria-label="Menu do usuário">
            <span class="app-avatar" id="app-avatar">…</span>
            <svg class="app-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          <div class="app-menu-pop app-user-menu" id="app-user-menu" hidden>
            <p class="app-user-nome" id="app-user-nome"></p>
            <a href="${base}#perfil" class="app-user-item">Meu Perfil</a>
            <button type="button" class="app-user-item" id="btn-sair">Sair</button>
          </div>
        </div>
      </div>
    </header>`;

  document.querySelector('[data-layout="menu"]').outerHTML = htmlMenu;
  document.querySelector('[data-layout="topo"]').outerHTML = htmlTopo;

  /* ---------- USUÁRIO ---------- */
  const ouvintes = [];
  let usuarioAtual = NivelDevAuth.getUser();

  const iniciais = (nome) => {
    const partes = (nome || '').trim().split(/\s+/).filter(Boolean);
    if (!partes.length) return '?';
    return (partes[0][0] + (partes.length > 1 ? partes[partes.length - 1][0] : '')).toUpperCase();
  };

  function mostrarUsuario(usuario) {
    usuarioAtual = usuario;
    const nome = (usuario && usuario.nome) || '';
    $('app-avatar').textContent = iniciais(nome);
    $('app-user-nome').textContent = (usuario && (usuario.email || usuario.nome)) || '';
    ouvintes.forEach((fn) => fn(usuario));
  }

  mostrarUsuario(usuarioAtual); // na hora, com o que está salvo

  // confirma com o servidor se o token ainda vale (pode ter expirado)
  NivelDevAuth.api.me()
    .then(({ user }) => mostrarUsuario(user))
    .catch((erro) => {
      if (erro.status === 401) {
        NivelDevAuth.logout();
        window.location.replace('login.html');
      }
      // outros erros (servidor fora do ar etc.): mantém o que já está na tela
    });

  /* ---------- MENUS SUSPENSOS (usuário e notificações) ---------- */
  const pops = [
    { botao: $('app-user-btn'), menu: $('app-user-menu') },
    { botao: $('btn-notif'),    menu: $('menu-notif') },
  ];

  function fecharPops(exceto) {
    pops.forEach((p) => {
      if (p === exceto) return;
      p.menu.hidden = true;
      p.botao.setAttribute('aria-expanded', 'false');
    });
  }

  pops.forEach((p) => {
    p.botao.addEventListener('click', (e) => {
      e.stopPropagation();
      fecharPops(p);
      p.menu.hidden = !p.menu.hidden;
      p.botao.setAttribute('aria-expanded', String(!p.menu.hidden));
      if (p.botao.id === 'btn-notif') $('notif-ponto').hidden = true; // "leu" as notificações
    });
    p.menu.addEventListener('click', (e) => e.stopPropagation());
  });
  document.addEventListener('click', () => fecharPops(null));

  $('btn-sair').addEventListener('click', () => {
    NivelDevAuth.logout();
    window.location.href = 'login.html';
  });

  /* ---------- TEMA E MENU RECOLHIDO ---------- */
  $('btn-tema').addEventListener('click', () => NivelDevPrefs.alternarTema());

  const botaoRecolher = $('app-collapse');
  function atualizarBotaoRecolher() {
    const recolhido = NivelDevPrefs.menuRecolhido();
    const texto = recolhido ? 'Expandir menu' : 'Recolher menu';
    botaoRecolher.setAttribute('aria-expanded', String(!recolhido));
    botaoRecolher.setAttribute('aria-label', texto);
    botaoRecolher.setAttribute('data-tip', texto);
  }
  botaoRecolher.addEventListener('click', () => {
    NivelDevPrefs.alternarMenu();
    atualizarBotaoRecolher();
  });
  atualizarBotaoRecolher();

  /* ---------- BUSCA DO TOPO ---------- */
  const busca = $('app-busca-global');

  document.addEventListener('keydown', (e) => {
    const digitando = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      busca.focus();
    } else if (e.key === '/' && !digitando) {
      e.preventDefault();
      busca.focus();
    } else if (e.key === 'Escape') {
      fecharPops(null);
      if (document.activeElement === busca) busca.blur();
    }
  });

  // TODO: ligar à busca de verdade quando existir uma API
  busca.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && busca.value.trim()) {
      NivelDevUI.toast('A busca geral ainda está em desenvolvimento.', 'info');
    }
  });

  /* ---------- API PARA AS TELAS ---------- */
  window.NivelDevLayout = {
    // chama a função agora (com o usuário salvo) e de novo quando o servidor confirmar
    usuario(fn) {
      ouvintes.push(fn);
      fn(usuarioAtual);
    },
  };
})();
