/* ============================================================
   NívelDev — lista de exercícios (categoria.html)
   Lista em rolagem (sem paginação), com busca e os estados de
   carregando (esqueleto), vazio e erro. Todos os exercícios são em Python.
   Abre como categoria.html?id=<categoria> (vindo da tela de
   Exercícios) ou só categoria.html para ver todos.
   O menu, o topo e a proteção da página ficam em js/shell.js.
   Os dados vêm de js/dados.js (ainda são exemplos).
   ============================================================ */

(function () {
  if (!window.NivelDevShell) return; // shell.js já mandou para o login

  var Shell = NivelDevShell;
  var esc = Shell.esc;

  var SETA = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  var ICONE_BUSCA = '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>';
  var ICONE_PASTA = '<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>';
  var ICONE_NUVEM = '<svg viewBox="0 0 24 24"><path d="M7 18a4 4 0 01-.7-7.9A6 6 0 0118 9.5 4.3 4.3 0 0117.5 18z"/><path d="M4 4l16 16"/></svg>';

  /* ---------- ELEMENTOS ---------- */
  var $ = function (id) { return document.getElementById(id); };
  var lista = $('cat-lista');
  var estado = $('cat-estado');
  var contador = $('cat-contador');
  var busca = $('cat-busca');

  /* ---------- CATEGORIA DA URL ---------- */
  var categoriaId = new URLSearchParams(window.location.search).get('id');
  var nomeCategoria = NDDados.nomeCategoria(categoriaId);
  var daCategoria = [];

  if (nomeCategoria) {
    $('cat-titulo').textContent = nomeCategoria;
    document.title = nomeCategoria + ' — Exercícios — NívelDev';
  }

  /* ---------- DIFICULDADE ----------
     1–3 fácil, 4–6 médio, 7–10 difícil */
  function nivelDe(d) { return d <= 3 ? 'facil' : d <= 6 ? 'medio' : 'dificil'; }
  var ROTULO = { facil: 'Fácil', medio: 'Médio', dificil: 'Difícil' };

  // 4 barrinhas: cada uma vale 2,5 pontos; a última pode ficar parcialmente cheia
  function barras(dificuldade) {
    var cheias = (dificuldade / 10) * 4;
    var html = '';
    for (var i = 0; i < 4; i++) {
      var pct = Math.max(0, Math.min(1, cheias - i)) * 100;
      html += '<span class="cat-barra"><span style="width:' + pct + '%"></span></span>';
    }
    return html;
  }

  /* ---------- ESTADOS ---------- */
  function esqueleto() {
    lista.setAttribute('aria-busy', 'true');
    estado.innerHTML = '';
    lista.innerHTML = new Array(6).join(
      '<li aria-hidden="true"><div class="cat-linha">' +
        '<div><span class="sk sk-titulo" style="width:40%"></span><span class="sk sk-linha" style="margin-top:10px;width:70%"></span></div>' +
        '<span class="sk sk-linha" style="width:120px"></span>' +
        '<span class="sk sk-linha" style="width:100px;height:38px;border-radius:999px;justify-self:end"></span>' +
      '</div></li>'
    );
    contador.textContent = '';
  }

  function mostrarEstado(icone, titulo, texto, acao, ehErro) {
    lista.setAttribute('aria-busy', 'false');
    lista.innerHTML = '';
    estado.innerHTML =
      '<div class="estado' + (ehErro ? ' is-erro' : '') + '">' +
        '<div class="estado-icone">' + icone + '</div>' +
        '<h2>' + esc(titulo) + '</h2><p>' + esc(texto) + '</p>' +
        (acao ? '<button type="button" class="btn-fantasma" id="estado-acao">' + esc(acao) + '</button>' : '') +
      '</div>';
    contador.textContent = '';
  }

  /* ---------- RENDERIZAÇÃO ---------- */
  function render(itens) {
    if (!itens.length) {
      if (!daCategoria.length) {
        mostrarEstado(ICONE_PASTA, 'Ainda não há exercícios aqui', 'Esta categoria está sendo preparada. Que tal praticar em outra?', null);
        var voltar = document.createElement('a');
        voltar.className = 'btn-fantasma';
        voltar.href = 'exercicios.html';
        voltar.textContent = 'Ver outras categorias';
        estado.querySelector('.estado').appendChild(voltar);
      } else {
        mostrarEstado(ICONE_BUSCA, 'Nenhum exercício encontrado',
          'Não achamos nada para “' + busca.value.trim() + '”. Tente outra palavra.', 'Limpar busca');
        $('estado-acao').addEventListener('click', function () {
          busca.value = '';
          filtrar();
          busca.focus();
        });
      }
      return;
    }

    estado.innerHTML = '';
    lista.setAttribute('aria-busy', 'false');
    lista.innerHTML = itens.map(function (e) {
      var nivel = nivelDe(e.dificuldade);
      return '' +
        '<li>' +
          '<article class="cat-linha">' +
            '<div>' +
              '<h3>' + esc(e.titulo) + '</h3>' +
              '<p>' + esc(e.desc) + '</p>' +
            '</div>' +
            '<div class="cat-dif is-' + nivel + '" aria-label="Dificuldade ' + ROTULO[nivel] + ', ' + e.dificuldade + ' de 10">' +
              '<span class="cat-barras" aria-hidden="true">' + barras(e.dificuldade) + '</span>' +
              '<span class="tag-dif is-' + nivel + '" aria-hidden="true">' + ROTULO[nivel] + '</span>' +
            '</div>' +
            '<a class="cat-resolver" href="resolver.html?id=' + e.id + '">Resolver ' + SETA + '</a>' +
          '</article>' +
        '</li>';
    }).join('');

    contador.textContent = itens.length === 1 ? 'Mostrando 1 exercício' : 'Mostrando ' + itens.length + ' exercícios';
  }

  /* ---------- FILTROS ---------- */
  function filtrar() {
    var termo = Shell.normalizar(busca.value.trim());
    render(daCategoria.filter(function (e) {
      return Shell.normalizar(e.titulo).indexOf(termo) >= 0 || Shell.normalizar(e.desc).indexOf(termo) >= 0;
    }));
  }

  busca.addEventListener('input', filtrar);

  /* ---------- CARREGAR ---------- */
  function carregar() {
    esqueleto();
    NDDados.carregarExercicios().then(function (todos) {
      daCategoria = nomeCategoria ? todos.filter(function (e) { return e.categoria === categoriaId; }) : todos;
      filtrar();
    }).catch(function () {
      mostrarEstado(ICONE_NUVEM, 'Não foi possível carregar',
        'O servidor não respondeu. Verifique sua conexão e tente de novo.', 'Tentar de novo', true);
      $('estado-acao').addEventListener('click', carregar);
      Shell.toast('Não foi possível carregar os exercícios', 'erro');
    });
  }

  carregar();
})();
