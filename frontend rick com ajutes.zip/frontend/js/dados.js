/* ============================================================
   NívelDev — dados de exemplo (um lugar só)
   ATENÇÃO: ainda não existe API de cursos/exercícios/progresso no
   back-end, então tudo aqui é EXEMPLO. Quando as rotas existirem,
   troque o conteúdo das funções carregar...() por um fetch na API
   (as telas já tratam carregando, vazio e erro).
   Carregado antes de shell.js e das páginas que usam estes dados.
   ============================================================ */

(function () {
  var categorias = [
    { id: "iniciante",   nome: "Iniciante",            desc: "Comece sua jornada com exercícios básicos.",              total: 12, icone: "play" },
    { id: "python",      nome: "Python",               desc: "Sintaxe e fundamentos da linguagem Python.",              total: 18, icone: "terminal" },
    { id: "strings",     nome: "Strings",              desc: "Manipulação e processamento de textos.",                  total: 15, icone: "text" },
    { id: "estruturas",  nome: "Estruturas de Dados",  desc: "Listas, pilhas, filas e estruturas avançadas.",           total: 14, icone: "layers" },
    { id: "logica",      nome: "Lógica",               desc: "Desafios de lógica e raciocínio computacional.",          total: 16, icone: "logic" },
    { id: "outros",      nome: "Outros",               desc: "Exercícios variados para expandir seus conhecimentos.",   total: 10, icone: "more" },
    { id: "variaveis",   nome: "Variáveis e Tipos",    desc: "Declaração, tipos primitivos e conversões.",              total: 11, icone: "code" },
    { id: "condicionais",nome: "Condicionais",         desc: "Tomada de decisão com if, elif e else.",                  total: 13, icone: "branch" },
    { id: "repeticao",   nome: "Laços de Repetição",   desc: "Pratique for, while e controle de fluxo.",                total: 17, icone: "loop" },
    { id: "funcoes",     nome: "Funções",              desc: "Parâmetros, retorno e reutilização de código.",           total: 15, icone: "code" },
    { id: "listas",      nome: "Listas",               desc: "Criação, fatiamento e métodos de listas.",                total: 14, icone: "layers" },
    { id: "dicionarios", nome: "Dicionários",          desc: "Pares chave-valor e buscas eficientes.",                  total: 12, icone: "box" },
    { id: "tuplas",      nome: "Tuplas e Conjuntos",   desc: "Coleções imutáveis e operações de conjuntos.",            total: 9,  icone: "box" },
    { id: "recursao",    nome: "Recursão",             desc: "Resolva problemas chamando a própria função.",            total: 10, icone: "loop" },
    { id: "ordenacao",   nome: "Ordenação",            desc: "Bubble, insertion, merge e quick sort.",                  total: 12, icone: "sort" },
    { id: "busca",       nome: "Algoritmos de Busca",  desc: "Busca linear, binária e suas variações.",                 total: 8,  icone: "search" },
    { id: "poo",         nome: "Orientação a Objetos", desc: "Classes, objetos, herança e polimorfismo.",               total: 16, icone: "box" },
    { id: "arquivos",    nome: "Arquivos",             desc: "Leitura e escrita de arquivos de texto e CSV.",           total: 9,  icone: "file" },
    { id: "excecoes",    nome: "Exceções",             desc: "Tratamento de erros com try e except.",                   total: 8,  icone: "alert" },
    { id: "modulos",     nome: "Módulos",              desc: "Importação e uso da biblioteca padrão.",                  total: 7,  icone: "layers" },
    { id: "regex",       nome: "Expressões Regulares", desc: "Padrões para validar e extrair textos.",                  total: 9,  icone: "text" },
    { id: "datas",       nome: "Datas e Horas",        desc: "Trabalhe com datetime e formatação de datas.",            total: 8,  icone: "clock" },
    { id: "matrizes",    nome: "Matrizes",             desc: "Listas bidimensionais e operações com matrizes.",         total: 11, icone: "math" },
    { id: "pilhas",      nome: "Pilhas e Filas",       desc: "Implemente estruturas LIFO e FIFO.",                      total: 10, icone: "layers" },
    { id: "arvores",     nome: "Árvores",              desc: "Árvores binárias, percursos e buscas.",                   total: 9,  icone: "logic" },
    { id: "grafos",      nome: "Grafos",               desc: "Representação, BFS, DFS e caminhos.",                     total: 10, icone: "graph" },
    { id: "dinamica",    nome: "Programação Dinâmica", desc: "Otimize soluções com memorização.",                       total: 8,  icone: "logic" },
    { id: "gulosos",     nome: "Algoritmos Gulosos",   desc: "Escolhas locais para soluções ótimas.",                   total: 7,  icone: "check" },
    { id: "numeros",     nome: "Teoria dos Números",   desc: "Primos, MDC, MMC e divisibilidade.",                      total: 12, icone: "math" },
    { id: "combinatoria",nome: "Combinatória",         desc: "Permutações, combinações e arranjos.",                    total: 8,  icone: "math" },
    { id: "geometria",   nome: "Geometria",            desc: "Áreas, distâncias e coordenadas.",                        total: 9,  icone: "math" },
    { id: "bits",        nome: "Manipulação de Bits",  desc: "Operadores bit a bit e representação binária.",           total: 7,  icone: "code" },
    { id: "compreensoes",nome: "Compreensões",         desc: "List, dict e set comprehensions.",                        total: 10, icone: "code" },
    { id: "lambdas",     nome: "Funções Lambda",       desc: "Funções anônimas com map, filter e sorted.",              total: 8,  icone: "code" },
    { id: "geradores",   nome: "Geradores",            desc: "Iteradores e a palavra-chave yield.",                     total: 6,  icone: "loop" },
    { id: "decoradores", nome: "Decoradores",          desc: "Estenda funções de forma elegante.",                      total: 6,  icone: "layers" },
    { id: "json",        nome: "JSON",                 desc: "Serialização e leitura de dados estruturados.",           total: 7,  icone: "file" },
    { id: "apis",        nome: "Consumo de APIs",      desc: "Requisições HTTP e tratamento de respostas.",             total: 6,  icone: "globe" },
    { id: "testes",      nome: "Testes",               desc: "Escreva testes com assert e unittest.",                   total: 7,  icone: "check" },
    { id: "depuracao",   nome: "Depuração",            desc: "Encontre e corrija erros em códigos prontos.",            total: 9,  icone: "search" },
    { id: "formatacao",  nome: "Formatação de Saída",  desc: "f-strings, alinhamento e casas decimais.",                total: 8,  icone: "text" },
    { id: "entrada",     nome: "Entrada e Saída",      desc: "Leitura de dados com input e exibição com print.",        total: 10, icone: "code" },
    { id: "hashing",     nome: "Hashing",              desc: "Tabelas hash e contagem de frequências.",                 total: 6,  icone: "lock" },
    { id: "criptografia",nome: "Criptografia Básica",  desc: "Cifras de César, Vigenère e codificação.",                total: 7,  icone: "lock" },
    { id: "simulacao",   nome: "Simulação",            desc: "Modele situações do mundo real em código.",               total: 8,  icone: "clock" },
    { id: "jogos",       nome: "Jogos Simples",        desc: "Pedra-papel-tesoura, forca e adivinhação.",               total: 9,  icone: "play" },
    { id: "desafios",    nome: "Desafios Semanais",    desc: "Problemas novos toda semana para testar você.",           total: 12, icone: "check" },
    { id: "entrevistas", nome: "Entrevistas Técnicas", desc: "Questões clássicas de processos seletivos.",              total: 14, icone: "logic" },
  ];

  var exercicios = [
    { id: 1,  titulo: 'Soma de Dois Números',      desc: 'Leia dois números e mostre a soma deles.',              dificuldade: 1,  categoria: 'iniciante',  linguagem: 'python' },
    { id: 2,  titulo: 'Par ou Ímpar',              desc: 'Informe se um número digitado é par ou ímpar.',         dificuldade: 1,  categoria: 'iniciante',  linguagem: 'python' },
    { id: 3,  titulo: 'Maior de Três Números',     desc: 'Descubra qual é o maior entre três números.',           dificuldade: 2,  categoria: 'iniciante',  linguagem: 'python' },
    { id: 4,  titulo: 'Média de Notas',            desc: 'Calcule a média de quatro notas e diga se foi aprovado.', dificuldade: 2, categoria: 'iniciante',  linguagem: 'python' },
    { id: 5,  titulo: 'Tabuada',                   desc: 'Mostre a tabuada de 1 a 10 de um número informado.',    dificuldade: 2,  categoria: 'iniciante',  linguagem: 'python' },
    { id: 6,  titulo: 'Conversor de Temperatura',  desc: 'Converta graus Celsius para Fahrenheit.',               dificuldade: 2,  categoria: 'python',     linguagem: 'python' },
    { id: 7,  titulo: 'Calculadora Simples',       desc: 'Faça as quatro operações com dois números.',            dificuldade: 3,  categoria: 'python',     linguagem: 'python' },
    { id: 8,  titulo: 'Contagem de Vogais',        desc: 'Conte quantas vogais existem em uma frase.',            dificuldade: 3,  categoria: 'strings',    linguagem: 'python' },
    { id: 9,  titulo: 'Inverter uma Palavra',      desc: 'Mostre uma palavra escrita de trás para frente.',       dificuldade: 3,  categoria: 'strings',    linguagem: 'python' },
    { id: 10, titulo: 'Contar Palavras',           desc: 'Conte quantas palavras existem em um texto.',           dificuldade: 3,  categoria: 'strings',    linguagem: 'python' },
    { id: 11, titulo: 'Maior Elemento da Lista',   desc: 'Encontre o maior número de uma lista sem usar max().',  dificuldade: 3,  categoria: 'estruturas', linguagem: 'python' },
    { id: 12, titulo: 'Fatorial',                  desc: 'Calcule o fatorial de um número informado.',            dificuldade: 4,  categoria: 'logica',     linguagem: 'python' },
    { id: 13, titulo: 'Palíndromo',                desc: 'Verifique se uma palavra é igual de trás para frente.', dificuldade: 4,  categoria: 'strings',    linguagem: 'python' },
    { id: 14, titulo: 'Remover Duplicados',        desc: 'Remova os itens repetidos de uma lista.',               dificuldade: 5,  categoria: 'estruturas', linguagem: 'python' },
    { id: 15, titulo: 'Ordenar Lista',             desc: 'Ordene uma lista de números sem usar sort().',          dificuldade: 6,  categoria: 'estruturas', linguagem: 'python' },
    { id: 16, titulo: 'Verificar Número Primo',    desc: 'Verifique se um número é primo.',                       dificuldade: 7,  categoria: 'logica',     linguagem: 'python' },
    { id: 17, titulo: 'Primos até N',              desc: 'Mostre todos os números primos até um limite.',         dificuldade: 8,  categoria: 'logica',     linguagem: 'python' },
    { id: 18, titulo: 'Sequência de Fibonacci',    desc: 'Mostre os N primeiros números da sequência.',           dificuldade: 9,  categoria: 'logica',     linguagem: 'python' },
  ];

  // dificuldade e progresso de cada categoria (exemplo)
  var DIFICEIS = ['estruturas', 'recursao', 'arvores', 'grafos', 'dinamica', 'gulosos', 'combinatoria', 'bits', 'geradores', 'decoradores', 'criptografia', 'entrevistas'];
  var FACEIS = ['iniciante', 'python', 'strings', 'variaveis', 'condicionais', 'entrada', 'formatacao', 'outros', 'jogos'];
  var FEITOS = { iniciante: 8 }; // casa com os "8 exercícios concluídos" da home
  categorias.forEach(function (c) {
    c.nivel = DIFICEIS.indexOf(c.id) >= 0 ? 'dificil' : FACEIS.indexOf(c.id) >= 0 ? 'facil' : 'medio';
    c.feitos = FEITOS[c.id] || 0;
  });

  var NOMES_CATEGORIA = {};
  categorias.forEach(function (c) { NOMES_CATEGORIA[c.id] = c.nome; });

  // ---------- gamificação (exemplo) ----------
  var NIVEIS = [
    { nome: 'Iniciante',   min: 0 },
    { nome: 'Aprendiz',    min: 100 },
    { nome: 'Programador', min: 250 },
    { nome: 'Dev',         min: 500 },
    { nome: 'Avançado',    min: 900 },
    { nome: 'Mestre',      min: 1500 }
  ];

  function calcularNivel(xp) {
    var i = 0;
    while (i < NIVEIS.length - 1 && xp >= NIVEIS[i + 1].min) i++;
    var atual = NIVEIS[i];
    var proximo = NIVEIS[i + 1] || null;
    return {
      numero: i + 1,
      nome: atual.nome,
      proximoNome: proximo ? proximo.nome : null,
      xpNoNivel: proximo ? xp - atual.min : 0,
      xpDoNivel: proximo ? proximo.min - atual.min : 0,
      faltam: proximo ? proximo.min - xp : 0,
      pct: proximo ? Math.round(((xp - atual.min) / (proximo.min - atual.min)) * 100) : 100
    };
  }

  var perfil = {
    xp: 340,
    sequenciaDias: 4,
    exerciciosConcluidos: 8,
    cursosEmAndamento: 1,
    cursoAtual: {
      titulo: 'Lógica de Programação',
      descricao: 'Aprenda os fundamentos da lógica e programe com confiança.',
      capa: 'logica',   // arquivo em img/cursos/ (sem .webp)
      progresso: 65     // 0 a 100
    },
    conquistas: [
      { id: 'primeiro',  nome: 'Primeiro código',    desc: 'Resolveu o primeiro exercício',  icone: 'code',  ganha: true },
      { id: 'cinco',     nome: '5 exercícios',        desc: 'Resolveu 5 exercícios',          icone: 'check', ganha: true },
      { id: 'seq3',      nome: 'Em ritmo',            desc: '3 dias seguidos praticando',     icone: 'fogo',  ganha: true },
      { id: 'dez',       nome: '10 exercícios',       desc: 'Resolveu 10 exercícios',         icone: 'check', ganha: false },
      { id: 'seq7',      nome: 'Semana completa',     desc: '7 dias seguidos praticando',     icone: 'fogo',  ganha: false },
      { id: 'strings',   nome: 'Mestre das strings',  desc: 'Concluiu a categoria Strings',   icone: 'texto', ganha: false }
    ]
  };

  // ---------- "API" simulada ----------
  // Devolve uma Promise depois de um tempinho, como um fetch de verdade.
  function simular(valor) {
    return new Promise(function (ok) { setTimeout(function () { ok(valor); }, 450); });
  }

  window.NDDados = {
    categorias: categorias,
    exercicios: exercicios,
    perfil: perfil,
    nomeCategoria: function (id) { return NOMES_CATEGORIA[id]; },
    calcularNivel: calcularNivel,
    carregarCategorias: function () { return simular(categorias); },
    carregarExercicios: function () { return simular(exercicios); }
  };
})();
