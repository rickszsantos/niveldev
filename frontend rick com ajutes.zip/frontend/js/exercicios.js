/* ============================================================
   NívelDev — tela de Exercícios (exercicios.html)
   Lista de categorias com busca e paginação, mais os estados de
   carregando (esqueleto), vazio e erro.
   O menu, o topo e a proteção da página ficam em js/shell.js.
   Os dados vêm de js/dados.js (ainda são exemplos).
   ============================================================ */

(function () {
  if (!window.NivelDevShell) return; // shell.js já mandou para o login

  var Shell = NivelDevShell;
  var esc = Shell.esc;

  // ===== ÍCONES (SVG inline) =====
  var ICONS = {
    play:    '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z" fill="currentColor" stroke="none"/></svg>',
    math:    '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 12h18M12 3v18M6 7.5h3M15 7.5h3M16.5 6v3M6 16.5h3M15 15l3 3M18 15l-3 3"/></svg>',
    text:    '<span class="ex-icone-texto">Aa</span>',
    layers:  '<svg viewBox="0 0 24 24"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/><path d="M3 17.5l9 5 9-5" opacity=".8"/></svg>',
    logic:   '<svg viewBox="0 0 24 24"><rect x="9" y="2" width="6" height="5" rx="1"/><rect x="2" y="17" width="5" height="5" rx="1"/><rect x="9.5" y="17" width="5" height="5" rx="1"/><rect x="17" y="17" width="5" height="5" rx="1"/><path d="M12 7v10M4.5 17v-4h15v4"/></svg>',
    more:    '<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="2" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="2" fill="currentColor" stroke="none"/></svg>',
    code:    '<svg viewBox="0 0 24 24"><path d="M8 7l-5 5 5 5M16 7l5 5-5 5"/></svg>',
    loop:    '<svg viewBox="0 0 24 24"><path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/></svg>',
    branch:  '<svg viewBox="0 0 24 24"><circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="9" r="2"/><path d="M6 7v10M18 11c0 4-6 3-12 6"/></svg>',
    file:    '<svg viewBox="0 0 24 24"><path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg>',
    box:     '<svg viewBox="0 0 24 24"><path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/></svg>',
    alert:   '<svg viewBox="0 0 24 24"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/></svg>',
    search:  '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
    sort:    '<svg viewBox="0 0 24 24"><path d="M7 4v16M3 16l4 4 4-4M14 6h7M14 12h5M14 18h3"/></svg>',
    graph:   '<svg viewBox="0 0 24 24"><circle cx="5" cy="6" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M7 6h10M6 8l5 8.5M18 8l-5 8.5"/></svg>',
    lock:    '<svg viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
    check:   '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></svg>',
    clock:   '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
    globe:   '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/></svg>',
    terminal:'<svg viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M6 9l3 3-3 3M12 15h6"/></svg>',
    cloud:   '<svg viewBox="0 0 24 24"><path d="M7 18a4 4 0 01-.7-7.9A6 6 0 0118 9.5 4.3 4.3 0 0117.5 18z"/><path d="M4 4l16 16"/></svg>'
  };

  var ARROW = '<svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  var PREV  = '<svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg>';
  var NEXT  = '<svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg>';

  var ROTULO_NIVEL = { facil: 'Fácil', medio: 'Médio', dificil: 'Difícil' };

  /* ============================================================
     ESTADO E RENDERIZAÇÃO
     ============================================================ */
  var POR_PAGINA = 6;
  var MAX_BOTOES = 3; // quantos números de página aparecem por vez
  var categorias = [];
  var filtradas = [];
  var paginaAtual = 1;

  var $ = function (id) { return document.getElementById(id); };
  var grid = $('ex-grid');
  var paginacao = $('ex-paginacao');
  var contador = $('ex-contador');
  var busca = $('ex-busca');

  // ----- estados -----
  function esqueleto() {
    grid.setAttribute('aria-busy', 'true');
    grid.innerHTML = new Array(POR_PAGINA + 1).join(
      '<div class="app-card ex-card ex-card-sk" aria-hidden="true">' +
        '<span class="sk sk-bloco"></span>' +
        '<div class="ex-info"><span class="sk sk-titulo"></span>' +
        '<span class="sk sk-linha" style="margin-top:12px;width:90%"></span>' +
        '<span class="sk sk-linha" style="margin-top:8px;width:65%"></span>' +
        '<span class="sk sk-linha" style="margin-top:auto;width:100%;height:6px"></span></div>' +
      '</div>'
    );
    paginacao.innerHTML = '';
    contador.textContent = '';
  }

  function mostrarEstado(icone, titulo, texto, acao, ehErro) {
    grid.setAttribute('aria-busy', 'false');
    grid.innerHTML =
      '<div class="estado' + (ehErro ? ' is-erro' : '') + '">' +
        '<div class="estado-icone">' + ICONS[icone] + '</div>' +
        '<h2>' + esc(titulo) + '</h2><p>' + esc(texto) + '</p>' +
        (acao ? '<button type="button" class="btn-fantasma" id="estado-acao">' + esc(acao) + '</button>' : '') +
      '</div>';
    paginacao.innerHTML = '';
    contador.textContent = '';
  }

  function estadoVazio(termo) {
    mostrarEstado('search', 'Nenhuma categoria encontrada',
      'Não achamos nada para “' + termo + '”. Tente outra palavra ou confira a ortografia.', 'Limpar busca');
    $('estado-acao').addEventListener('click', function () {
      busca.value = '';
      filtrar();
      busca.focus();
    });
  }

  function estadoErro() {
    mostrarEstado('cloud', 'Não foi possível carregar',
      'O servidor não respondeu. Verifique sua conexão e tente de novo.', 'Tentar de novo', true);
    $('estado-acao').addEventListener('click', carregar);
  }

  // ----- lista -----
  function cartao(c) {
    var pct = c.total ? Math.round((c.feitos / c.total) * 100) : 0;
    return '' +
      '<a class="app-card ex-card" href="categoria.html?id=' + esc(c.id) + '">' +
        '<div class="ex-icone" aria-hidden="true">' + (ICONS[c.icone] || ICONS.code) + '</div>' +
        '<div class="ex-info">' +
          '<h3>' + esc(c.nome) + '</h3>' +
          '<p>' + esc(c.desc) + '</p>' +
          '<div class="ex-rodape-card">' +
            '<div class="ex-linha-meta">' +
              '<span class="tag-dif is-' + c.nivel + '">' + ROTULO_NIVEL[c.nivel] + '</span>' +
              '<span class="ex-qtd">' + c.feitos + ' de ' + c.total + ' exercícios</span>' +
            '</div>' +
            '<div class="mini-barra" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct + '" aria-label="Progresso em ' + esc(c.nome) + '"><span data-pct="' + pct + '"></span></div>' +
          '</div>' +
        '</div>' +
        '<span class="ex-seta" aria-hidden="true">' + ARROW + '</span>' +
      '</a>';
  }

  function renderCards() {
    var inicio = (paginaAtual - 1) * POR_PAGINA;
    grid.setAttribute('aria-busy', 'false');
    grid.innerHTML = filtradas.slice(inicio, inicio + POR_PAGINA).map(cartao).join('');

    // as barras de progresso crescem depois de aparecer
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        grid.querySelectorAll('[data-pct]').forEach(function (el) { el.style.width = el.dataset.pct + '%'; });
      });
    });
  }

  function renderPaginacao() {
    var totalPaginas = Math.max(1, Math.ceil(filtradas.length / POR_PAGINA));

    // janela de páginas visíveis centrada na atual
    var inicio = Math.max(1, paginaAtual - Math.floor(MAX_BOTOES / 2));
    var fim = Math.min(totalPaginas, inicio + MAX_BOTOES - 1);
    inicio = Math.max(1, fim - MAX_BOTOES + 1);

    var html = '<button type="button" class="ex-pag-btn ex-pag-nav" data-page="' + (paginaAtual - 1) + '" ' + (paginaAtual === 1 ? 'disabled' : '') + ' aria-label="Página anterior">' + PREV + '</button>';
    for (var p = inicio; p <= fim; p++) {
      var ativo = p === paginaAtual;
      html += '<button type="button" class="ex-pag-btn ' + (ativo ? 'is-active' : '') + '" data-page="' + p + '" ' + (ativo ? 'aria-current="page"' : '') + '>' + p + '</button>';
    }
    html += '<button type="button" class="ex-pag-btn ex-pag-nav" data-page="' + (paginaAtual + 1) + '" ' + (paginaAtual === totalPaginas ? 'disabled' : '') + ' aria-label="Próxima página">' + NEXT + '</button>';
    paginacao.innerHTML = html;

    var de = (paginaAtual - 1) * POR_PAGINA + 1;
    var ate = Math.min(paginaAtual * POR_PAGINA, filtradas.length);
    contador.textContent = 'Mostrando ' + de + ' – ' + ate + ' de ' + filtradas.length + ' categorias';
  }

  function render() {
    if (!filtradas.length) { estadoVazio(busca.value.trim()); return; }
    renderCards();
    renderPaginacao();
  }

  paginacao.addEventListener('click', function (e) {
    var btn = e.target.closest('.ex-pag-btn');
    if (!btn || btn.disabled) return;
    paginaAtual = Number(btn.dataset.page);
    render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  function filtrar() {
    var termo = Shell.normalizar(busca.value.trim());
    filtradas = categorias.filter(function (c) {
      return Shell.normalizar(c.nome).indexOf(termo) >= 0 || Shell.normalizar(c.desc).indexOf(termo) >= 0;
    });
    paginaAtual = 1;
    render();
  }

  busca.addEventListener('input', filtrar);

  /* ---------- CARREGAR ---------- */
  function carregar() {
    esqueleto();
    NDDados.carregarCategorias().then(function (lista) {
      categorias = lista;
      filtrar();
    }).catch(function () {
      estadoErro();
      Shell.toast('Não foi possível carregar as categorias', 'erro');
    });
  }

  carregar();
})();
