/* ============================================================
   NívelDev — home (home.html)
   1) Dados da home (nível, XP, sequência, conquistas, progresso)
   2) Navegação entre as telas da home: Início, Progresso, Perfil
   O menu, o topo e a proteção da página ficam em js/shell.js.
   Os dados vêm de js/dados.js (ainda são exemplos).
   ============================================================ */

(function () {
  if (!window.NivelDevShell) return; // shell.js já mandou para o login

  var Shell = NivelDevShell;
  var D = NDDados;
  var $ = function (id) { return document.getElementById(id); };

  /* ---------- 1) DADOS ---------- */

  var ICONES_CONQUISTA = {
    code:  '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    fogo:  '<path d="M12 3c.6 3.2 4.5 5 4.5 9.5a4.5 4.5 0 01-9 0c0-1.7.7-2.9 1.7-3.9.3 1.2 1 1.9 1.8 2 .2-3 .3-5.2 1-7.6z"/>',
    texto: '<path d="M4 18l5-12 5 12M6 14h6M16 18v-7m0 0a2.5 2.5 0 100 5"/>'
  };
  var CADEADO = '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>';

  function crescerBarra(preenchimento, barra, pct) {
    barra.setAttribute('aria-valuenow', String(pct));
    // espera um quadro para a barra "crescer" com animação
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { preenchimento.style.width = pct + '%'; });
    });
  }

  function mostrarNivel(p) {
    var n = D.calcularNivel(p.xp);
    $('nivel-num').textContent = n.numero;
    $('nivel-nome').textContent = n.nome;
    Shell.contar($('xp-total'), p.xp, 1000);
    $('xp-faltam').textContent = n.proximoNome
      ? '· faltam ' + n.faltam + ' XP para ' + n.proximoNome
      : '· nível máximo!';
    crescerBarra($('xp-fill'), $('xp-barra'), n.pct);
  }

  function mostrarDados(p) {
    mostrarNivel(p);

    Shell.contar($('stat-seq'), p.sequenciaDias);
    $('stat-seq-rotulo').textContent = p.sequenciaDias === 1 ? 'dia seguido' : 'dias seguidos';
    Shell.contar($('stat-exercicios'), p.exerciciosConcluidos);
    $('stat-exercicios-rotulo').textContent = p.exerciciosConcluidos === 1 ? 'Exercício concluído' : 'Exercícios concluídos';
    Shell.contar($('stat-cursos'), p.cursosEmAndamento);
    $('stat-cursos-rotulo').textContent = p.cursosEmAndamento === 1 ? 'Curso em andamento' : 'Cursos em andamento';

    var c = p.cursoAtual;
    $('curso-titulo').textContent = c.titulo;
    $('curso-desc').textContent = c.descricao;
    $('curso-capa').src = 'img/cursos/' + c.capa + '.webp';
    Shell.contar($('curso-pct'), c.progresso);
    crescerBarra($('curso-barra-fill'), $('curso-barra'), c.progresso);

    $('conquistas').innerHTML = p.conquistas.map(function (q) {
      return '<li class="hm-conq' + (q.ganha ? '' : ' is-bloqueada') + '">' +
        '<span class="hm-conq-icone"><svg viewBox="0 0 24 24" aria-hidden="true">' + (q.ganha ? ICONES_CONQUISTA[q.icone] : CADEADO) + '</svg></span>' +
        '<strong>' + Shell.esc(q.nome) + '</strong>' +
        '<span>' + Shell.esc(q.desc) + '</span>' +
        '<span class="sr-only">' + (q.ganha ? 'Conquistada' : 'Bloqueada') + '</span>' +
        '</li>';
    }).join('');
  }

  function mostrarProgresso() {
    var itens = D.categorias.slice(0, 8);
    $('progresso-lista').innerHTML = itens.map(function (c) {
      var pct = Math.round((c.feitos / c.total) * 100);
      return '<div class="hm-linha">' +
        '<div class="hm-linha-txt"><strong>' + Shell.esc(c.nome) + '</strong><span>' + c.feitos + ' de ' + c.total + ' exercícios</span></div>' +
        '<div class="mini-barra" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct + '" aria-label="Progresso em ' + Shell.esc(c.nome) + '"><span data-pct="' + pct + '"></span></div>' +
        '<span class="hm-linha-pct">' + pct + '%</span></div>';
    }).join('');
  }

  function animarBarras(raiz) {
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        raiz.querySelectorAll('[data-pct]').forEach(function (el) { el.style.width = el.dataset.pct + '%'; });
      });
    });
  }

  function mostrarUsuario(u) {
    var nome = (u && u.nome) || '';
    var partes = nome.trim().split(/\s+/).filter(Boolean);
    $('hero-nome').textContent = partes[0] || 'aluno'; // textContent: sem risco de HTML injetado
    $('perfil-avatar').textContent = ((partes[0] || '?')[0] + (partes.length > 1 ? partes[partes.length - 1][0] : '')).toUpperCase();
    $('perfil-nome').textContent = nome || 'Aluno';
    $('perfil-email').textContent = (u && u.email) || '';
    var n = D.calcularNivel(D.perfil.xp);
    $('perfil-nivel').textContent = 'Nível ' + n.numero + ' · ' + n.nome;
  }

  /* ---------- 2) NAVEGAÇÃO ---------- */
  var TITULOS = { inicio: 'Início', cursos: 'Cursos', progresso: 'Meu Progresso', perfil: 'Meu Perfil' };
  var TELAS = ['inicio', 'progresso', 'perfil'];

  function irPara() {
    var nome = window.location.hash.replace('#', '');
    var tela = TITULOS[nome] ? nome : 'inicio';

    Shell.marcarAtivo(tela);

    TELAS.forEach(function (t) { $('view-' + t).hidden = t !== tela; });
    var emDev = TELAS.indexOf(tela) < 0;
    $('view-dev').hidden = !emDev;
    $('dev-titulo').textContent = emDev ? TITULOS[tela] + ' — em desenvolvimento' : '';
    document.title = TITULOS[tela] + ' — NívelDev';

    if (tela === 'progresso') animarBarras($('view-progresso'));
    Shell.fecharMenu();
    window.scrollTo(0, 0);
  }

  /* ---------- Tema (na tela de perfil) ---------- */
  function marcarTema() {
    document.querySelectorAll('#perfil-tema button').forEach(function (b) {
      var ativo = b.dataset.tema === NDPrefs.tema();
      b.setAttribute('aria-checked', String(ativo));
      b.classList.toggle('is-ativo', ativo);
    });
  }
  $('perfil-tema').addEventListener('click', function (e) {
    var b = e.target.closest('button');
    if (!b) return;
    NDPrefs.definirTema(b.dataset.tema);
    marcarTema();
    Shell.toast('Tema salvo', 'sucesso');
  });

  /* ---------- Início ---------- */
  mostrarDados(D.perfil);
  mostrarProgresso();
  mostrarUsuario(Shell.usuario());
  marcarTema();
  document.addEventListener('nd:usuario', function (e) { mostrarUsuario(e.detail); });
  window.addEventListener('hashchange', irPara);
  irPara();
})();
