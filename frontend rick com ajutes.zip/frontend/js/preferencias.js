/* ============================================================
   NívelDev — preferências da área logada (carregado no <head>)
   Aplica o tema (claro/escuro) e o menu recolhido ANTES de a página
   ser desenhada, assim nada "pisca" ao trocar de tela.
   O tema "auto" segue o sistema operacional.
   ============================================================ */

(function () {
  var CHAVE_MENU = 'niveldev_menu_recolhido';
  var CHAVE_TEMA = 'niveldev_tema'; // 'claro' | 'escuro' | 'auto'
  var raiz = document.documentElement;

  function ler(chave) {
    try { return localStorage.getItem(chave); } catch (e) { return null; }
  }

  function salvar(chave, valor) {
    try { localStorage.setItem(chave, valor); } catch (e) { /* sem storage: vale só nesta página */ }
  }

  function escuroDoSistema() {
    return !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  }

  function preferenciaDeTema() {
    var t = ler(CHAVE_TEMA);
    return t === 'claro' || t === 'escuro' ? t : 'auto';
  }

  function aplicarTema() {
    var pref = preferenciaDeTema();
    var escuro = pref === 'escuro' || (pref === 'auto' && escuroDoSistema());
    raiz.setAttribute('data-theme', escuro ? 'dark' : 'light');
    return escuro;
  }

  if (ler(CHAVE_MENU) === '1') raiz.classList.add('menu-recolhido');
  aplicarTema();

  if (window.matchMedia) {
    var mq = matchMedia('(prefers-color-scheme: dark)');
    var aoMudar = function () { if (preferenciaDeTema() === 'auto') aplicarTema(); };
    if (mq.addEventListener) mq.addEventListener('change', aoMudar);
  }

  window.NDPrefs = {
    tema: preferenciaDeTema,
    definirTema: function (t) { salvar(CHAVE_TEMA, t); return aplicarTema(); },
    menuRecolhido: function () { return raiz.classList.contains('menu-recolhido'); },
    definirMenu: function (recolhido) {
      raiz.classList.toggle('menu-recolhido', recolhido);
      salvar(CHAVE_MENU, recolhido ? '1' : '0');
    }
  };

  // só liga as animações do menu depois do primeiro desenho
  document.addEventListener('DOMContentLoaded', function () {
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { raiz.classList.add('menu-animavel'); });
    });
  });
})();
