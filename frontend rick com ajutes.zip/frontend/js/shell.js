/* ============================================================
   NívelDev — estrutura comum da área logada (shell)
   Um lugar só para o que antes estava copiado em cada página:
   1) Proteção: quem não está logado volta para o login
   2) Menu lateral e barra do topo (busca Ctrl+K, tema, sino, usuário)
   3) Avisos: toasts e faixa "servidor indisponível"
   4) Utilitários para as páginas: NivelDevShell.toast / contar / esc

   Para mudar o menu, edite a lista ITENS abaixo.
   Cada página só precisa de:
     <body class="app-page" data-pagina="exercicios">
     <aside id="app-sidebar"></aside>
     <header id="app-topbar"></header>
     <div id="app-backdrop" hidden></div>
   Depende de js/auth.js (e, para a busca, de js/dados.js).
   ============================================================ */

(function () {
  'use strict';

  /* ---------- 1) PROTEÇÃO ---------- */
  if (!window.NivelDevAuth || !NivelDevAuth.getToken()) {
    window.location.replace('login.html');
    return;
  }

  var $ = function (id) { return document.getElementById(id); };
  var reduzirMovimento = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  // escapa texto antes de ir para dentro de innerHTML
  function esc(texto) {
    return String(texto == null ? '' : texto).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // remove acentos: a busca funciona com "logica" ou "lógica"
  function normalizar(s) {
    return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  }

  /* ---------- ÍCONES ---------- */
  var I = {
    inicio:     '<path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-4v-6H9v6H5a1 1 0 01-1-1v-9z"/>',
    cursos:     '<path d="M2 9l10-5 10 5-10 5L2 9z"/><path d="M6 11.5V16c0 1.4 2.7 3 6 3s6-1.6 6-3v-4.5"/><path d="M22 9v6"/>',
    exercicios: '<path d="M8 8l-4 4 4 4"/><path d="M16 8l4 4-4 4"/><path d="M13.5 5l-3 14"/>',
    progresso:  '<rect x="3" y="13" width="4" height="7" rx="1.5"/><rect x="10" y="8" width="4" height="12" rx="1.5"/><rect x="17" y="3" width="4" height="17" rx="1.5"/>',
    perfil:     '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
    busca:      '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    sino:       '<path d="M6 9a6 6 0 0112 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9z"/><path d="M10 20a2 2 0 004 0"/>',
    sol:        '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    lua:        '<path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z"/>',
    seta:       '<path d="M14.5 6l-6 6 6 6"/>',
    menu:       '<path d="M4 6h16M4 12h16M4 18h16"/>',
    baixo:      '<path d="M6 9l6 6 6-6"/>',
    pagina:     '<path d="M14 3H6a1 1 0 00-1 1v16a1 1 0 001 1h12a1 1 0 001-1V8z"/><path d="M14 3v5h5"/>',
    pasta:      '<path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>',
    fechar:     '<path d="M6 6l12 12M18 6L6 18"/>',
    ok:         '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    aviso:      '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
    info:       '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'
  };
  var svg = function (nome) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + I[nome] + '</svg>'; };

  /* ---------- 2) MENU ----------
     visivel:false esconde o item até a tela existir. */
  var ITENS = [
    { id: 'inicio',     rotulo: 'Início',        href: 'home.html#inicio' },
    { id: 'cursos',     rotulo: 'Cursos',        href: 'home.html#cursos', visivel: false },
    { id: 'exercicios', rotulo: 'Exercícios',    href: 'exercicios.html' },
    { id: 'progresso',  rotulo: 'Meu Progresso', href: 'home.html#progresso' },
    { separador: true },
    { id: 'perfil',     rotulo: 'Meu Perfil',    href: 'home.html#perfil' }
  ];

  var paginaAtual = document.body.dataset.pagina || '';

  function htmlMenu() {
    var itens = ITENS.filter(function (i) { return i.visivel !== false; }).map(function (i) {
      if (i.separador) return '<hr class="app-nav-sep">';
      var ativo = i.id === paginaAtual;
      return '<a href="' + i.href + '" class="app-nav-item' + (ativo ? ' is-active' : '') + '" data-item="' + i.id + '" data-tip="' + i.rotulo + '"' +
        (ativo ? ' aria-current="page"' : '') + '>' + svg(i.id) + '<span class="app-nav-label">' + i.rotulo + '</span></a>';
    }).join('');

    return '' +
      '<button type="button" class="app-collapse" id="app-collapse" aria-label="Recolher menu" aria-controls="app-sidebar" aria-expanded="true" data-tip="Recolher menu">' + svg('seta') + '</button>' +
      '<a href="home.html#inicio" class="app-logo" aria-label="NívelDev — início">' +
        '<img class="app-logo-full app-logo-claro" src="img/logo-niveldev.webp" alt="NívelDev" width="148" height="30">' +
        '<img class="app-logo-full app-logo-escuro" src="img/logo-niveldev-branco.webp" alt="" aria-hidden="true" width="148" height="30">' +
        '<img class="app-logo-mini" src="img/logo-niveldev-icone.webp" alt="" aria-hidden="true" width="36" height="36">' +
      '</a>' +
      '<nav class="app-nav" aria-label="Seções">' + itens + '</nav>';
  }

  function htmlTopo() {
    var mac = /Mac|iPhone|iPad/.test(navigator.platform || '');
    return '' +
      '<button type="button" class="app-menu-btn" id="app-menu-btn" aria-label="Abrir menu" aria-controls="app-sidebar" aria-expanded="false">' + svg('menu') + '</button>' +

      '<button type="button" class="app-busca" id="app-busca" aria-haspopup="dialog">' +
        svg('busca') + '<span class="app-busca-txt">Buscar…</span><kbd class="app-kbd">' + (mac ? '⌘ K' : 'Ctrl K') + '</kbd>' +
      '</button>' +

      '<div class="app-actions">' +
        '<button type="button" class="app-icon-btn" id="app-tema" aria-label="Alternar tema"></button>' +

        '<div class="app-pop-wrap">' +
          '<button type="button" class="app-icon-btn" id="app-sino" aria-haspopup="true" aria-expanded="false" aria-label="Notificações">' + svg('sino') + '</button>' +
          '<div class="app-pop app-notif" id="app-notif" hidden>' +
            '<p class="app-pop-titulo">Notificações</p>' +
            '<div class="app-notif-vazio">' + svg('sino') + '<strong>Tudo em dia</strong><span>Você não tem notificações no momento.</span></div>' +
          '</div>' +
        '</div>' +

        '<div class="app-user">' +
          '<button type="button" class="app-user-btn" id="app-user-btn" aria-haspopup="true" aria-expanded="false" aria-label="Menu do usuário">' +
            '<span class="app-avatar" id="app-avatar">…</span><svg class="app-chevron" viewBox="0 0 24 24" aria-hidden="true">' + I.baixo + '</svg>' +
          '</button>' +
          '<div class="app-user-menu" id="app-user-menu" hidden>' +
            '<p class="app-user-nome" id="app-user-nome"></p>' +
            '<a href="home.html#perfil" class="app-user-item">Meu Perfil</a>' +
            '<button type="button" class="app-user-item" id="btn-sair">Sair</button>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  $('app-sidebar').classList.add('app-sidebar');
  $('app-sidebar').setAttribute('aria-label', 'Menu principal');
  $('app-sidebar').innerHTML = htmlMenu();
  $('app-topbar').classList.add('app-topbar');
  $('app-topbar').innerHTML = htmlTopo();
  $('app-backdrop').classList.add('app-backdrop');

  var lateral = $('app-sidebar');
  var fundo = $('app-backdrop');
  var botaoMenu = $('app-menu-btn');

  /* ---------- Menu recolhido (telas largas) ---------- */
  var botaoRecolher = $('app-collapse');
  function atualizarRecolher() {
    var recolhido = NDPrefs.menuRecolhido();
    botaoRecolher.setAttribute('aria-expanded', String(!recolhido));
    botaoRecolher.setAttribute('aria-label', recolhido ? 'Expandir menu' : 'Recolher menu');
    botaoRecolher.setAttribute('data-tip', recolhido ? 'Expandir menu' : 'Recolher menu');
  }
  botaoRecolher.addEventListener('click', function () {
    NDPrefs.definirMenu(!NDPrefs.menuRecolhido());
    atualizarRecolher();
  });
  atualizarRecolher();

  /* ---------- Menu lateral no celular (gaveta) ---------- */
  function abrirMenuLateral() {
    lateral.classList.add('is-open');
    fundo.hidden = false;
    botaoMenu.setAttribute('aria-expanded', 'true');
  }
  function fecharMenuLateral() {
    lateral.classList.remove('is-open');
    fundo.hidden = true;
    botaoMenu.setAttribute('aria-expanded', 'false');
  }
  botaoMenu.addEventListener('click', abrirMenuLateral);
  fundo.addEventListener('click', fecharMenuLateral);

  /* ---------- Pop-ups do topo (usuário e notificações) ---------- */
  var pops = [
    { botao: $('app-user-btn'), caixa: $('app-user-menu') },
    { botao: $('app-sino'),     caixa: $('app-notif') }
  ];
  function fecharPops(exceto) {
    pops.forEach(function (p) {
      if (p === exceto) return;
      p.caixa.hidden = true;
      p.botao.setAttribute('aria-expanded', 'false');
    });
  }
  pops.forEach(function (p) {
    p.botao.addEventListener('click', function (e) {
      e.stopPropagation();
      fecharPops(p);
      p.caixa.hidden = !p.caixa.hidden;
      p.botao.setAttribute('aria-expanded', String(!p.caixa.hidden));
    });
    p.caixa.addEventListener('click', function (e) { e.stopPropagation(); });
  });
  document.addEventListener('click', function () { fecharPops(null); });
  $('app-user-menu').querySelectorAll('a').forEach(function (a) {
    a.addEventListener('click', function () { fecharPops(null); });
  });

  $('btn-sair').addEventListener('click', function () {
    NivelDevAuth.logout();
    window.location.href = 'login.html';
  });

  /* ---------- Tema claro/escuro ---------- */
  var botaoTema = $('app-tema');
  function atualizarBotaoTema() {
    var escuro = document.documentElement.getAttribute('data-theme') === 'dark';
    // mostra o ícone do tema que será ativado ao clicar
    botaoTema.innerHTML = svg(escuro ? 'sol' : 'lua');
    botaoTema.setAttribute('aria-label', escuro ? 'Ativar tema claro' : 'Ativar tema escuro');
    botaoTema.setAttribute('title', escuro ? 'Tema claro' : 'Tema escuro');
  }
  botaoTema.addEventListener('click', function () {
    var escuro = document.documentElement.getAttribute('data-theme') === 'dark';
    NDPrefs.definirTema(escuro ? 'claro' : 'escuro');
    atualizarBotaoTema();
    document.dispatchEvent(new CustomEvent('nd:tema'));
    toast(escuro ? 'Tema claro ativado' : 'Tema escuro ativado', 'info');
  });
  atualizarBotaoTema();

  /* ---------- 3) TOASTS ---------- */
  var pilha = document.createElement('div');
  pilha.className = 'nd-toasts';
  pilha.setAttribute('aria-live', 'polite');
  document.body.appendChild(pilha);

  function toast(mensagem, tipo, ms) {
    tipo = tipo || 'info';
    var el = document.createElement('div');
    el.className = 'nd-toast is-' + tipo;
    el.setAttribute('role', tipo === 'erro' ? 'alert' : 'status');
    el.innerHTML = svg(tipo === 'sucesso' ? 'ok' : tipo === 'erro' ? 'aviso' : 'info') +
      '<span></span><button type="button" class="nd-toast-x" aria-label="Fechar aviso">' + svg('fechar') + '</button>';
    el.querySelector('span').textContent = mensagem; // textContent: sem HTML injetado

    var timer;
    function sair() {
      clearTimeout(timer);
      el.classList.add('is-saindo');
      setTimeout(function () { el.remove(); }, reduzirMovimento ? 0 : 200);
    }
    el.querySelector('.nd-toast-x').addEventListener('click', sair);
    pilha.appendChild(el);
    while (pilha.children.length > 3) pilha.firstChild.remove();
    timer = setTimeout(sair, ms || 3500);
  }

  /* ---------- Faixa "servidor indisponível" ---------- */
  var faixa = null;
  function mostrarFaixa(texto) {
    if (!faixa) {
      faixa = document.createElement('div');
      faixa.className = 'app-faixa';
      faixa.setAttribute('role', 'alert');
      faixa.innerHTML = svg('aviso') + '<span></span><button type="button" class="app-faixa-btn">Tentar de novo</button>';
      faixa.querySelector('button').addEventListener('click', verificarSessao);
      $('app-topbar').insertAdjacentElement('afterend', faixa);
    }
    faixa.querySelector('span').textContent = texto;
  }
  function esconderFaixa() {
    if (faixa) { faixa.remove(); faixa = null; }
  }

  window.addEventListener('offline', function () {
    mostrarFaixa('Você está sem conexão. Algumas coisas podem não funcionar até a internet voltar.');
  });
  window.addEventListener('online', function () {
    esconderFaixa();
    toast('Conexão restabelecida', 'sucesso');
    verificarSessao();
  });

  /* ---------- Usuário ---------- */
  function iniciais(nome) {
    var partes = (nome || '').trim().split(/\s+/).filter(Boolean);
    if (!partes.length) return '?';
    return (partes[0][0] + (partes.length > 1 ? partes[partes.length - 1][0] : '')).toUpperCase();
  }

  var usuario = NivelDevAuth.getUser();
  function mostrarUsuario(u) {
    usuario = u || usuario;
    var nome = (usuario && usuario.nome) || '';
    $('app-avatar').textContent = iniciais(nome);
    $('app-user-nome').textContent = (usuario && (usuario.email || usuario.nome)) || '';
    document.dispatchEvent(new CustomEvent('nd:usuario', { detail: usuario }));
  }
  mostrarUsuario(usuario);

  // confirma com o servidor se o token ainda vale (pode ter expirado)
  function verificarSessao() {
    return NivelDevAuth.api.me().then(function (r) {
      esconderFaixa();
      mostrarUsuario(r.user);
    }).catch(function (erro) {
      if (erro.status === 401) {
        NivelDevAuth.logout();
        window.location.replace('login.html');
        return;
      }
      mostrarFaixa('Não conseguimos falar com o servidor agora. O que você vê pode estar desatualizado.');
    });
  }

  /* ---------- Busca global (Ctrl+K) ---------- */
  var botaoBusca = $('app-busca');
  var paleta = document.createElement('div');
  paleta.className = 'nd-paleta';
  paleta.hidden = true;
  paleta.innerHTML =
    '<div class="nd-paleta-caixa" role="dialog" aria-modal="true" aria-label="Busca global">' +
      '<div class="nd-paleta-campo">' + svg('busca') +
        '<input type="text" id="nd-paleta-input" placeholder="Buscar páginas, categorias e exercícios…" autocomplete="off" ' +
          'role="combobox" aria-expanded="true" aria-controls="nd-paleta-lista" aria-label="Buscar">' +
        '<kbd class="app-kbd">Esc</kbd>' +
      '</div>' +
      '<ul class="nd-paleta-lista" id="nd-paleta-lista" role="listbox"></ul>' +
    '</div>';
  document.body.appendChild(paleta);

  var campo = $('nd-paleta-input');
  var listaBusca = $('nd-paleta-lista');
  var resultados = [];
  var selecionado = 0;

  function fontesDeBusca() {
    var d = window.NDDados;
    var itens = ITENS.filter(function (i) { return !i.separador && i.visivel !== false; }).map(function (i) {
      return { grupo: 'Páginas', icone: i.id, titulo: i.rotulo, href: i.href, texto: i.rotulo };
    });
    if (d) {
      d.categorias.forEach(function (c) {
        itens.push({ grupo: 'Categorias', icone: 'pasta', titulo: c.nome, detalhe: c.total + ' exercícios', href: 'categoria.html?id=' + c.id, texto: c.nome + ' ' + c.desc });
      });
      d.exercicios.forEach(function (e) {
        itens.push({ grupo: 'Exercícios', icone: 'pagina', titulo: e.titulo, detalhe: d.nomeCategoria(e.categoria) || 'Python', href: 'categoria.html?id=' + e.categoria, texto: e.titulo + ' ' + e.desc });
      });
    }
    return itens;
  }

  function desenharBusca() {
    var termo = normalizar(campo.value.trim());
    var todos = fontesDeBusca();
    resultados = termo
      ? todos.filter(function (i) { return normalizar(i.texto).indexOf(termo) >= 0; }).slice(0, 8)
      : todos.filter(function (i) { return i.grupo === 'Páginas'; });
    selecionado = 0;

    if (!resultados.length) {
      listaBusca.innerHTML = '<li class="nd-paleta-vazio" role="presentation">Nada encontrado para “<b></b>”.</li>';
      listaBusca.querySelector('b').textContent = campo.value.trim();
      campo.removeAttribute('aria-activedescendant');
      return;
    }

    var html = '';
    var grupo = '';
    resultados.forEach(function (r, i) {
      if (r.grupo !== grupo) {
        grupo = r.grupo;
        html += '<li class="nd-paleta-grupo" role="presentation">' + grupo + '</li>';
      }
      html += '<li role="option" id="nd-res-' + i + '" class="nd-paleta-item" data-i="' + i + '" aria-selected="' + (i === 0) + '">' +
        svg(r.icone) + '<span class="nd-paleta-titulo">' + esc(r.titulo) + '</span>' +
        (r.detalhe ? '<span class="nd-paleta-detalhe">' + esc(r.detalhe) + '</span>' : '') + '</li>';
    });
    listaBusca.innerHTML = html;
    campo.setAttribute('aria-activedescendant', 'nd-res-0');
  }

  function marcarSelecionado(i) {
    if (!resultados.length) return;
    selecionado = (i + resultados.length) % resultados.length;
    listaBusca.querySelectorAll('.nd-paleta-item').forEach(function (el) {
      var ativo = Number(el.dataset.i) === selecionado;
      el.setAttribute('aria-selected', String(ativo));
      if (ativo) { el.scrollIntoView({ block: 'nearest' }); campo.setAttribute('aria-activedescendant', el.id); }
    });
  }

  function abrirBusca() {
    fecharPops(null);
    fecharMenuLateral();
    paleta.hidden = false;
    campo.value = '';
    desenharBusca();
    campo.focus();
  }
  function fecharBusca() {
    if (paleta.hidden) return;
    paleta.hidden = true;
    botaoBusca.focus();
  }
  function irPara(r) {
    if (r) window.location.href = r.href;
  }

  botaoBusca.addEventListener('click', abrirBusca);
  paleta.addEventListener('mousedown', function (e) { if (e.target === paleta) fecharBusca(); });
  campo.addEventListener('input', desenharBusca);
  campo.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowDown') { e.preventDefault(); marcarSelecionado(selecionado + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); marcarSelecionado(selecionado - 1); }
    else if (e.key === 'Enter') { e.preventDefault(); irPara(resultados[selecionado]); }
  });
  listaBusca.addEventListener('click', function (e) {
    var item = e.target.closest('.nd-paleta-item');
    if (item) irPara(resultados[Number(item.dataset.i)]);
  });
  listaBusca.addEventListener('mousemove', function (e) {
    var item = e.target.closest('.nd-paleta-item');
    if (item && Number(item.dataset.i) !== selecionado) marcarSelecionado(Number(item.dataset.i));
  });

  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      if (paleta.hidden) abrirBusca(); else fecharBusca();
    } else if (e.key === 'Escape') {
      if (!paleta.hidden) { fecharBusca(); return; }
      fecharPops(null);
      fecharMenuLateral();
    }
  });

  /* ---------- Transição suave entre páginas ---------- */
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a[href]');
    if (!a || reduzirMovimento || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || a.target) return;
    var url = new URL(a.href, location.href);
    if (url.origin !== location.origin || url.pathname === location.pathname) return; // mesma página: sem transição
    e.preventDefault();
    document.body.classList.add('is-saindo');
    setTimeout(function () { window.location.href = a.href; }, 140);
  });
  // voltar pelo botão do navegador não pode deixar a página invisível
  window.addEventListener('pageshow', function () { document.body.classList.remove('is-saindo'); });

  /* ---------- Utilitários para as páginas ---------- */

  // números "contando" até o valor final
  function contar(el, fim, ms) {
    fim = Number(fim) || 0;
    if (reduzirMovimento || fim === 0) { el.textContent = fim; return; }
    var t0 = null;
    ms = ms || 900;
    function passo(t) {
      if (t0 === null) t0 = t;
      var p = Math.min(1, (t - t0) / ms);
      el.textContent = Math.round(fim * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(passo);
    }
    requestAnimationFrame(passo);
  }

  // destaca o item do menu (a home troca de seção sem recarregar)
  function marcarAtivo(id) {
    document.querySelectorAll('.app-nav-item').forEach(function (item) {
      var ativo = item.dataset.item === id;
      item.classList.toggle('is-active', ativo);
      if (ativo) item.setAttribute('aria-current', 'page');
      else item.removeAttribute('aria-current');
    });
  }

  window.NivelDevShell = {
    toast: toast,
    contar: contar,
    esc: esc,
    normalizar: normalizar,
    marcarAtivo: marcarAtivo,
    fecharMenu: fecharMenuLateral,
    usuario: function () { return usuario; },
    icone: svg
  };

  verificarSessao();
})();
