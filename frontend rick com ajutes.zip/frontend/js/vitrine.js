/* ============================================================
   NívelDev — painel de vitrine das telas de login e cadastro
   Mostra um exemplo do que a pessoa vai encontrar na plataforma.
   Preenche <aside id="auth-vitrine"> (conteúdo fixo, sem dados do usuário).
   ============================================================ */

(function () {
  var alvo = document.getElementById('auth-vitrine');
  if (!alvo) return;

  alvo.innerHTML =
    '<div class="vt-texto">' +
      '<h2>Pratique de verdade.<br>Suba de nível.</h2>' +
      '<p>Exercícios de programação corrigidos na hora, com XP a cada desafio resolvido.</p>' +
    '</div>' +

    '<div class="vt-janela" role="img" aria-label="Exemplo de exercício: média de notas em Python, com 3 testes aprovados e 30 XP ganhos">' +
      '<div class="vt-barra">' +
        '<span class="vt-pontos" aria-hidden="true"><i></i><i></i><i></i></span>' +
        '<span class="vt-arquivo">media_de_notas.py</span>' +
        '<span class="vt-dif">Fácil</span>' +
      '</div>' +
      '<pre class="vt-codigo" aria-hidden="true">' +
        '<span class="vt-n">1</span><span class="k">def</span> <span class="f">media</span>(notas):\n' +
        '<span class="vt-n">2</span>    total = <span class="f">sum</span>(notas)\n' +
        '<span class="vt-n">3</span>    <span class="k">return</span> total / <span class="f">len</span>(notas)\n' +
        '<span class="vt-n">4</span>\n' +
        '<span class="vt-n">5</span><span class="f">print</span>(media([<span class="n">7</span>, <span class="n">8.5</span>, <span class="n">9</span>, <span class="n">6.5</span>]))' +
      '</pre>' +
      '<ul class="vt-testes" aria-hidden="true">' +
        '<li><b>✓</b> Teste 1: notas altas</li>' +
        '<li><b>✓</b> Teste 2: notas iguais</li>' +
        '<li><b>✓</b> Teste 3: uma nota só</li>' +
      '</ul>' +
      '<div class="vt-xp" aria-hidden="true"><span>3 de 3 testes aprovados</span><strong>+30 XP</strong></div>' +
    '</div>';
})();
